##  QUESTÃO 01
import sqlite3
conexao = sqlite3.connect('banco1.db')
cursor = conexao.cursor()
cursor.execute('''
CREATE TABLE vendas (
    id INTEGER PRIMARY KEY,
    cliente_id INTEGER,
    valor_venda REAL
)
''')

cursor.executemany("INSERT INTO vendas (cliente_id, valor_venda) VALUES (?, ?)", [
    (1, 150.50),
    (2, 200.00),
    (1, 100.00),
    (3, 250.00),
    (2, 300.00)
])

def calcular_total_vendas():
    cursor.execute("SELECT SUM(valor_venda) FROM vendas")
    return cursor.fetchone()[0]

print("1. Total de vendas:", calcular_total_vendas())

# ##  QUESTÃO 02
#
# def calcular_media_vendas():
#     cursor.execute("SELECT AVG(valor_venda) FROM vendas")
#     return cursor.fetchone()[0]
#
# print("2. Média de vendas:", calcular_media_vendas())
#
#
# # Questão 3
# def valor_maximo_venda():
#     cursor.execute("SELECT MAX(valor_venda) FROM vendas")
#     return cursor.fetchone()[0]
#
# print("3. Valor máximo de venda:", valor_maximo_venda())
#
#
# # Questão 4
# def valor_minimo_venda():
#     cursor.execute("SELECT MIN(valor_venda) FROM vendas")
#     return cursor.fetchone()[0]
#
# print("4. Valor mínimo de venda:", valor_minimo_venda())
#
#
# # Questão 5
# def calcular_total_por_cliente(cliente_id):
#     cursor.execute("SELECT SUM(valor_venda) FROM vendas WHERE cliente_id = ?", (cliente_id,))
#     return cursor.fetchone()[0]
#
# print("5. Total de vendas por cliente (cliente 1):", calcular_total_por_cliente(1))
#
#
# # Questão 6
# cursor.execute("""
# CREATE TABLE funcionarios (
#     id INTEGER PRIMARY KEY,
#     nome TEXT,
#     salario REAL
# )
# """)
# cursor.executemany("INSERT INTO funcionarios (nome, salario) VALUES (?, ?)", [
#     ("João", 2500.00),
#     ("Maria", 3000.00),
#     ("Carlos", 2000.00),
#     ("Ana", 3500.00),
#     ("Pedro", 4000.00)
# ])
# def calcular_salario_total():
#     cursor.execute("SELECT SUM(salario) FROM funcionarios")
#     return cursor.fetchone()[0]
#
# print("6. Salário total dos funcionários:", calcular_salario_total())
#
#
# # Questão 7
# cursor.execute("""
# CREATE TABLE usuarios (
#     id INTEGER PRIMARY KEY,
#     nome TEXT,
#     idade INTEGER
# )
# """)
# cursor.executemany("INSERT INTO usuarios (nome, idade) VALUES (?, ?)", [
#     ("Alice", 25),
#     ("Bruno", 30),
#     ("Clara", 40),
#     ("Diego", 35),
#     ("Eva", 28),
#     ("Fábio", 22),
#     ("Gabriela", 50)
# ])
# def calcular_media_idades():
#     cursor.execute("SELECT AVG(idade) FROM usuarios")
#     return cursor.fetchone()[0]
#
# print("7. Média de idades dos usuários:", calcular_media_idades())
#
#
# # Questão 8
# def contar_usuarios_acima_de_30():
#     cursor.execute("SELECT COUNT(*) FROM usuarios WHERE idade > 30")
#     return cursor.fetchone()[0]
#
# print("8. Usuários com idade acima de 30:", contar_usuarios_acima_de_30())
#
#
# # Questão 9
# cursor.execute("""
# CREATE TABLE produtos (
#     id INTEGER PRIMARY KEY,
#     nome TEXT,
#     quantidade_estoque INTEGER,
#     preco REAL
# )
# """)
# cursor.executemany("INSERT INTO produtos (nome, quantidade_estoque, preco) VALUES (?, ?, ?)", [
#     ("Produto A", 10, 50.00),
#     ("Produto B", 20, 30.00),
#     ("Produto C", 15, 40.00),
#     ("Produto D", 5, 100.00),
#     ("Produto E", 8, 80.00)
# ])
# def calcular_estoque_total():
#     cursor.execute("SELECT SUM(quantidade_estoque) FROM produtos")
#     return cursor.fetchone()[0]
#
# print("9. Estoque total:", calcular_estoque_total())
#
#
# # Questão 10
# def calcular_receita_total():
#     cursor.execute("SELECT SUM(quantidade_estoque * preco) FROM produtos")
#     return cursor.fetchone()[0]
#
# print("10. Receita total do estoque:", calcular_receita_total())

conexao.close()